 { 'R', "blink_high", "K?", "tell python that we are ready to play" },
 { 'H', "blink_high", "K?", "tell python that the LED was set high" },
 { 'L', "blink_low", "K?", "tell python that the LED was set low" },
